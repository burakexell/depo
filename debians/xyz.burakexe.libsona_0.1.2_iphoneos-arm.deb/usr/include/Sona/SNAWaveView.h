#import "SNAView.h"

@interface SNAWaveView : SNAView
@property(nonatomic, retain) CAShapeLayer *shapeLayer;
@property(nonatomic) BOOL onlyLine;
@end